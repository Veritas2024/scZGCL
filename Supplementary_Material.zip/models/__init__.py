from .scZGCL import scZGCL_Trainer
from .scZGCL_MSE import scZGCL_MSE_Trainer